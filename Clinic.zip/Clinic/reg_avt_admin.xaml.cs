﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Clinic
{
    /// <summary>
    /// Логика взаимодействия для reg_avt_client.xaml
    /// </summary>
    public partial class reg_avt_admin : Window
    {
        СтоматологияEntities1 db = new СтоматологияEntities1();
        

        public reg_avt_admin()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow reg = new MainWindow();
            this.Close();
            reg.Show();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {

            int n = 0;
            if (Name6.Text == "" && Name7.Text == "") MessageBox.Show("Введите данные!");
            else
            {
                foreach (var clients in db.Администраторы)
                {
                    if (Name6.Text == clients.Логин && Name7.Text == clients.Пароль)
                    {
                        n = 1;
                        break;
                    }
                }
                if (n == 1)
                {
                    profil_admin pr = new profil_admin();
                    this.Close();
                    pr.Show();
                    MessageBox.Show("Добро пожаловать!");
                }
                else
                {
                    MessageBox.Show("Пользователь не зарегистрирован!");
                }
            }
        }
    }
}
