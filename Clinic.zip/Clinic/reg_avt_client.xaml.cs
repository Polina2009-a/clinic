﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Clinic
{
    /// <summary>
    /// Логика взаимодействия для reg_avt_client.xaml
    /// </summary>
    public partial class reg_avt_client : Window
    {
        public Клиенты _currentNed = new Клиенты();
        СтоматологияEntities1 db = new СтоматологияEntities1();

        public reg_avt_client()
        {
            InitializeComponent();
            DataContext = _currentNed;
        }

        void upd_sav() //Обновление ББ
        {
            db.SaveChanges();
            СтоматологияEntities1.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
           MainWindow reg = new MainWindow();
            this.Close();
            reg.Show();
        }

        void Clear() //Очистка боксов
        {
            Name1.Text = "";
            Name2.Text = "";
            Name3.Text = "";
            Name4.Text = "";
            Name5.Text = "";
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            int n = 0;
            Клиенты User = new Клиенты();
            if (Name1.Text == null) MessageBox.Show("Введите данные!");
            else
            {
                foreach (var item in db.Клиенты)
                {
                    if (item.Логин == Name1.Text)
                    {
                        User = item;
                        n = 1;
                    }
                }
                if (n == 1)
                {
                    MessageBox.Show("Такой логин уже используется!");
                }
                else
                {
                    if (Name1.Text != "" && Name2.Text != "" && Name3.Text != "" && Name4.Text != "" && Name5.Text != "")
                    {
                        Клиенты клиенты = new Клиенты();
                        клиенты.Логин = Name1.Text.Trim();
                        клиенты.Пароль = Name2.Text.Trim();
                        клиенты.Имя = Name3.Text.Trim();
                        клиенты.Фамилия = Name4.Text.Trim();
                        клиенты.Отчество = Name5.Text.Trim();
                        db.Клиенты.Add(клиенты);
                        upd_sav();
                        Clear();
                        MessageBox.Show("А теперь авторизируйтесь!");
                    }
                    else MessageBox.Show("Введите данные!");
                }
            }

           
        }

        public void Button_Click_2(object sender, RoutedEventArgs e)
        {
            int n = 0;
            if (Name6.Text == "" && Name7.Text == "") MessageBox.Show("Введите данные!");
            else
            {
                foreach (var clients in db.Клиенты)
                {
                    if (Name6.Text == clients.Логин && Name7.Text == clients.Пароль)
                    {
                        n = 1;
                        break;
                    }
                }
                if (n == 1)
                {
                    menu_client pr = new menu_client(Name6.Text);
                    this.Close();
                    pr.Show();
                    MessageBox.Show("Добро пожаловать!");

                }
                else
                {
                    MessageBox.Show("Пользователь не зарегистрирован!");
                }
            }
        }
    }
}