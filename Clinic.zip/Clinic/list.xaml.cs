﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Clinic
{
    /// <summary>
    /// Логика взаимодействия для reg_avt_client.xaml
    /// </summary>
    public partial class list : Window
    {
        private Записи _currentNed = new Записи();
        СтоматологияEntities1 db = new СтоматологияEntities1();
 
        public list()
        {       
            InitializeComponent();
            bd_sch.ItemsSource = СтоматологияEntities1.GetContext().Записи.ToList();
            bd_sch_Copy.ItemsSource = СтоматологияEntities1.GetContext().Клиенты.ToList();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            profil_admin reg = new profil_admin();
            this.Close();
            reg.Show();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            var current_item = СтоматологияEntities1.GetContext().Записи.ToList();
            current_item = current_item.Where(p => p.Логин_клиента.ToString().ToLower().Contains(serch.Text.ToLower())).ToList();
            bd_sch.ItemsSource = current_item;
        }

        private void Serch1_TextChanged(object sender, TextChangedEventArgs e)
        {

            var current_item = СтоматологияEntities1.GetContext().Клиенты.ToList();
            current_item = current_item.Where(p => p.Фамилия.ToString().ToLower().Contains(serch1.Text.ToLower())).ToList();
            bd_sch_Copy.ItemsSource = current_item;
        }

        void upd_sav() //Обновление ББ
        {
            db.SaveChanges();
            СтоматологияEntities1.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
            bd_sch.ItemsSource = СтоматологияEntities1.GetContext().Записи.ToList();
        }


        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            int n = 0;
            Записи User = new Записи();
            if (id_del.Text == null) MessageBox.Show("Введите ИД!");
            else
            {
                foreach (var item in db.Записи)
                {
                    if (item.ИД.ToString() == id_del.Text)
                    {
                        User = item;
                        n = 1;
                    }
                }
                if (n == 1)
                {
                    if (MessageBox.Show("Удалить?", "Удаление!",
                          MessageBoxButton.YesNo, MessageBoxImage.Warning).ToString() == "Yes"
                          && User != null)
                    {
                        db.Записи.Remove(User);
                        upd_sav();
                        MessageBox.Show("Запись удалена!");
                    }
                }
                else MessageBox.Show("Запись не найдена");
            }
        }
    }
}
