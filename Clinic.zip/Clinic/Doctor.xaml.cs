﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Clinic
{
    /// <summary>
    /// Логика взаимодействия для Doctor.xaml
    /// </summary>
    public partial class Doctor : Window
    {
        private Врачи _currentNed = new Врачи();
        СтоматологияEntities1 db = new СтоматологияEntities1();

        public Doctor()
        {
            InitializeComponent();
            bd_sch.ItemsSource = СтоматологияEntities1.GetContext().Врачи.ToList();
            DataContext = _currentNed;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            profil_admin reg = new profil_admin();
            this.Close();
            reg.Show();
        }

        void Clear() //Очистка боксов
        {
            Name1.Text = "";
            Name2.Text = "";
            Name3.Text = "";
            Name4.Text = "";
        }

        void upd_sav() //Обновление ББ
        {
            db.SaveChanges();
            СтоматологияEntities1.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
            bd_sch.ItemsSource = СтоматологияEntities1.GetContext().Врачи.ToList();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (Name1.Text != "" && Name2.Text != "" && Name4.Text != "" && Name3.Text != "")
            {
                Врачи записи = new Врачи();
                записи.Фамилия = Name1.Text.Trim();
                записи.Имя = Name2.Text.Trim();
                записи.Отчество = Name3.Text.Trim();
                записи.Специализация = Name4.Text.Trim();
                db.Врачи.Add(записи);
                upd_sav();
                Clear();
                MessageBox.Show("Врач добавлен!");
                db.SaveChanges();
            }
            else MessageBox.Show("Введите данные!");
        }

        private void Button_Click_2(object sender, RoutedEventArgs e) //Удаление врачей
        {
            int n = 0;
            Врачи User = new Врачи();
            if (id_del.Text == null) MessageBox.Show("Введите ИД!");
            else
            {
                foreach (var item in db.Врачи)
                {
                    if (item.Фамилия.ToString() == id_del.Text)
                    {
                        User = item;
                        n = 1;
                    }
                }

                if (n == 1)
                {
                    if (MessageBox.Show("Удалить врача?", "Удаление!",
                          MessageBoxButton.YesNo, MessageBoxImage.Warning).ToString() == "Yes"
                          && User != null)
                    {
                        db.Врачи.Remove(User);
                        upd_sav();
                        MessageBox.Show("Врач удален!");
                    }
                }
                else MessageBox.Show("Пользователь не найден!");
            }
        }
    }
}
