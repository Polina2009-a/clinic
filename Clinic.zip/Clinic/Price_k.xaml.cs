﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Clinic
{
    /// <summary>
    /// Логика взаимодействия для Price_k.xaml
    /// </summary>
    public partial class Price_k : Window
    {
        string login;

        public Price_k(string login)
        {
            InitializeComponent();
            bd_sch.ItemsSource = СтоматологияEntities1.GetContext().Услуги.ToList();
            this.login = login;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            menu_client reg = new menu_client(login);
            this.Close();
            reg.Show();
        }
    }
}
