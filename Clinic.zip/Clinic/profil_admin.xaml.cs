﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Clinic
{
    /// <summary>
    /// Логика взаимодействия для reg_avt_client.xaml
    /// </summary>
    public partial class profil_admin : Window
    {
        private Записи _currentNed = new Записи();
        СтоматологияEntities1 db = new СтоматологияEntities1();

        public profil_admin()
        {       
            InitializeComponent();
            DataContext = _currentNed;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow reg = new MainWindow();
            this.Close();
            reg.Show();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            list lis = new list();
            this.Close();
            lis.Show();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Doctor lis = new Doctor();
            this.Close();
            lis.Show();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
           Price lis = new Price();
            this.Close();
            lis.Show();
        }
    }
}


