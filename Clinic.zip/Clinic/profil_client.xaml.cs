﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Clinic
{
    /// <summary>
    /// Логика взаимодействия для reg_avt_client.xaml
    /// </summary>
    public partial class profil_client : Window
    {
        private Записи _currentNed = new Записи();
        СтоматологияEntities1 db = new СтоматологияEntities1();
        string login;

        public profil_client(string login)
        {       
            InitializeComponent();
            bd_sch.ItemsSource = СтоматологияEntities1.GetContext().Записи.ToList();
            Name1.ItemsSource = СтоматологияEntities1.GetContext().Врачи.ToList();
            DataContext = _currentNed;
            this.login = login;
            Name4.Text = login;
            var current_item = СтоматологияEntities1.GetContext().Записи.ToList();
            current_item = current_item.Where(p => p.Логин_клиента.ToString().ToLower().Contains(Name4.Text.ToLower())).ToList();
            bd_sch.ItemsSource = current_item;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
           menu_client reg = new menu_client(login);
            this.Close();
            reg.Show();
        }

        void Clear() //Очистка боксов
        {
            Name1.Text = "";
            Name2.Text = "";
            Name3.Text = "";
        }

        void upd_sav() //Обновление ББ
        {
            db.SaveChanges();
            СтоматологияEntities1.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
            bd_sch.ItemsSource = СтоматологияEntities1.GetContext().Записи.ToList();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (Name1.Text != "" && Name2.Text != "" && Name3.Text != "" && Name4.Text != "" )
            {
                Записи записи = new Записи();
                записи.Специализация = Name1.Text.Trim();
                записи.Дата_день = Name2.Text.Trim();
                записи.Дата_время = Name3.Text.Trim();
                записи.Логин_клиента = Name4.Text.Trim();
                db.Записи.Add(записи);
                upd_sav();
                Clear();
                var current_item = СтоматологияEntities1.GetContext().Записи.ToList();
                current_item = current_item.Where(p => p.Логин_клиента.ToString().ToLower().Contains(Name4.Text.ToLower())).ToList();
                bd_sch.ItemsSource = current_item;
                MessageBox.Show("Вы записаны! Если в это время врач не сможет принять Вас, то запись будет удалена в течение часа! Чтобы посмотреть актуальные записи, перезайдите на это форму.");
                db.SaveChanges();
            }
            else MessageBox.Show("Введите данные!");
        }
    }
}
