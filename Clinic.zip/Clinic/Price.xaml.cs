﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Clinic
{
    /// <summary>
    /// Логика взаимодействия для reg_avt_client.xaml
    /// </summary>
    public partial class Price : Window
    {
        private Услуги _currentNed = new Услуги();
        СтоматологияEntities1 db = new СтоматологияEntities1();


        public Price()
        {       
            InitializeComponent();
            bd_sch.ItemsSource = СтоматологияEntities1.GetContext().Услуги.ToList();
            DataContext = _currentNed;
   
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
           profil_admin reg = new profil_admin();
            this.Close();
            reg.Show();
        }

        void upd_sav() //Обновление ББ
        {
            db.SaveChanges();
            СтоматологияEntities1.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
            bd_sch.ItemsSource = СтоматологияEntities1.GetContext().Услуги.ToList();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            int n = 0;
            Услуги User = new Услуги();
            if (id_del.Text == null) MessageBox.Show("Введите ИД!");
            else
            {
                foreach (var item in db.Услуги)
                {
                    if (item.ИД.ToString() == id_del.Text)
                    {
                        User = item;
                        n = 1;
                    }
                }
                if (n == 1)
                {
                    if (MessageBox.Show("Удалить?", "Удаление!",
                          MessageBoxButton.YesNo, MessageBoxImage.Warning).ToString() == "Yes"
                          && User != null)
                    {
                        db.Услуги.Remove(User);
                        upd_sav();
                        MessageBox.Show("Услуга удален!");
                    }
                }
                else MessageBox.Show("Услуга не найдена!");
            }
        }
        void Clear() //Очистка боксов
        {
            Name2.Text = "";
            Name3.Text = "";
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            if (Name2.Text != "" && Name3.Text != "" )
            {
                Услуги записи = new Услуги();
                записи.Услуга = Name2.Text.Trim();
                записи.Цена = Name3.Text.Trim();
                db.Услуги.Add(записи);
                upd_sav();
                Clear();
                MessageBox.Show("Услуга добавлена!");
                db.SaveChanges();
            }
            else MessageBox.Show("Введите данные!");
        }
    }
}
